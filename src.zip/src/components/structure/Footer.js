import React, { Component } from 'react';

class Footer extends Component {

    render() {
        return (
            <footer>
                <p>All rights reserved | Tácio Belmonte 2018</p>
            </footer>
        );
    }
}

export default Footer;